import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CrabWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CrabWorld extends World
{

    /**
     * Constructor for objects of class CrabWorld.
     * 
     */
    public CrabWorld()
    {    
        super(560, 560, 1); 
        prepare();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Crab crab = new Crab();
        addObject(crab,412,295);
        Worm worm = new Worm();
        addObject(worm,393,186);
        Worm worm2 = new Worm();
        addObject(worm2,263,432);
        Worm worm3 = new Worm();
        addObject(worm3,210,259);
        Worm worm4 = new Worm();
        addObject(worm4,313,128);
        Worm worm5 = new Worm();
        addObject(worm5,100,263);
        Worm worm6 = new Worm();
        addObject(worm6,291,445);
        Worm worm7 = new Worm();
        addObject(worm7,452,463);
        crab.setLocation(102,352);
    }
}
