// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class lobster extends Actor
{

    /**
     * Act - do whatever the lobster wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    protected void act()
    {
        code__dummy__gf3gen__0 invalid#;
        if () {
        }
        if () {
        }
    }
}
